package com.cg.gsm.entities;

public interface DropdownList {
	public String getKey();

	public String getValue();
}
