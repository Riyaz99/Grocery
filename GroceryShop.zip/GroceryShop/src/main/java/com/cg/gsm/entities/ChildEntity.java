package com.cg.gsm.entities;

import javax.persistence.Entity;

@Entity
public class ChildEntity extends BaseEntity{

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
